public class StokException extends Exception {
    public StokException(String mesaj) {
        super(mesaj);
    }
}