public class SKTGecmisException extends Exception {
    public SKTGecmisException(String mesaj) {
        super(mesaj);
    }
}