import java.util.Date;

public class Gida extends Urun {
    private boolean veganMi;
    private int kalori;

    public Gida(String ad, String barkod, double fiyat, int stok, Date skt, boolean veganMi, int kalori) {
        super(ad, barkod, fiyat, stok, skt);
        this.veganMi = veganMi;
        this.kalori = kalori;
    }

    public String gidaBilgisi() {
        return getAd() + " - Vegan: " + veganMi + ", Kalori: " + kalori;
    }
}