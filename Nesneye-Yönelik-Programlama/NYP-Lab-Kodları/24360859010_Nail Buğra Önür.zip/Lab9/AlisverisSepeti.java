import java.util.ArrayList;
import java.util.Date;

public class AlisverisSepeti {
    private ArrayList<Urun> sepetUrunleri = new ArrayList<>();

    public AlisverisSepeti() {
    }

    public void sepeteEkle(Urun urun, int adet) throws SKTGecmisException, YetersizStokException, NegatifStokException {
        if (urun.sonKullanmaGectiMi()) {
            throw new SKTGecmisException("Son kullanma tarihi geçmiş ürün: " + urun.getAd());
        }
        urun.stokAzalt(adet);
        for (int i = 0; i < adet; i++) {
            sepetUrunleri.add(urun);
        }
    }

    public void sepetiGoster() {
        System.out.println("=== SEPET İÇERİĞİ ===");
        for (Urun u : sepetUrunleri) {
            System.out.println(u.getAd() + ": " + u.getFiyat() + " TL");
        }
        System.out.println("Toplam tutar: " + getToplamTutar() + " TL");
    }

    public double getToplamTutar() {
        double toplam = 0;
        for (Urun u : sepetUrunleri) {
            toplam += u.getFiyat();
        }
        return toplam;
    }

    // UML'de istenen yardımcı metot
    public static Date tarihOlustur(int yil, int ay, int gun) {
        return new Date(yil - 1900, ay - 1, gun);
    }
}