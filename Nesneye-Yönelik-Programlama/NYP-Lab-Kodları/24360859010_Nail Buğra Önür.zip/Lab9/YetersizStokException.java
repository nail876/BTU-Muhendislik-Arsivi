public class YetersizStokException extends StokException {
    public YetersizStokException(String mesaj) {
        super(mesaj);
    }
}