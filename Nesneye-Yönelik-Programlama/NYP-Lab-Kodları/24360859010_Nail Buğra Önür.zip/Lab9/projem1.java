import java.util.Date;

public class projem1 {
    public static void main(String[] args) {
        AlisverisSepeti sepet = new AlisverisSepeti();
        Elektronik laptop = new Elektronik("Oyun Laptopu", "101", 15000.0, 5, new Date(System.currentTimeMillis() + 1000000000L), 24, "Asus");

        try {
            sepet.sepeteEkle(laptop, 1);
            System.out.println("Ürün sepete eklendi. Toplam: " + sepet.getToplamTutar());
            
            sepet.sepeteEkle(laptop, 100);
        } catch (YetersizStokException e) {
            System.out.println("Hata yakalandı: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Beklenmeyen hata: " + e.getMessage());
        }
    }
}