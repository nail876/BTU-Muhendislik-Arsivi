import java.util.Date;

public class Urun {
    private String ad;
    private String barkod;
    private double fiyat;
    private int stok;
    private Date sonKullanmaTarihi;

    public Urun(String ad, String barkod, double fiyat, int stok, Date sonKullanmaTarihi) {
        this.ad = ad;
        this.barkod = barkod;
        this.fiyat = fiyat;
        this.stok = stok;
        this.sonKullanmaTarihi = sonKullanmaTarihi;
    }

    public boolean sonKullanmaGectiMi() {
        Date bugun = new Date();
        return sonKullanmaTarihi.before(bugun);
    }

    public void stokAzalt(int miktar) throws YetersizStokException, NegatifStokException {
        if (miktar < 0) {
            throw new NegatifStokException("Miktar negatif olamaz: " + miktar);
        }
        if (this.stok < miktar) {
            throw new YetersizStokException("Yetersiz stok! Mevcut: " + this.stok + ", İstenen: " + miktar);
        }
        this.stok -= miktar;
    }

    public String urunBilgisi() {
        return "Ürün: " + ad + ", Barkod: " + barkod + ", Fiyat: " + fiyat + ", Stok: " + stok;
    }

    public String getAd() { return ad; }
    public double getFiyat() { return fiyat; }
    public int getStok() { return stok; }
}