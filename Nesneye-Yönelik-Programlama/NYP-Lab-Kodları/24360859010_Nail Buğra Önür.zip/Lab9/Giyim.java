import java.util.Date;

public class Giyim extends Urun {
    private String beden;
    private String kumas;

    public Giyim(String ad, String barkod, double fiyat, int stok, Date skt, String beden, String kumas) {
        super(ad, barkod, fiyat, stok, skt);
        this.beden = beden;
        this.kumas = kumas;
    }

    public String giyimBilgisi() {
        return getAd() + " - Beden: " + beden + ", Kumaş: " + kumas;
    }
}