public class NegatifStokException extends StokException {
    public NegatifStokException(String mesaj) {
        super(mesaj);
    }
}