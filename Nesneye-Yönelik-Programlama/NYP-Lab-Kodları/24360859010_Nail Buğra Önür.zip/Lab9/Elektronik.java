import java.util.Date;

public class Elektronik extends Urun {
    private int garantiGunu;
    private String marka;

    public Elektronik(String ad, String barkod, double fiyat, int stok, Date skt, int garantiGunu, String marka) {
        super(ad, barkod, fiyat, stok, skt);
        this.garantiGunu = garantiGunu;
        this.marka = marka;
    }

    public String elektronikBilgisi() {
        return getAd() + " - Marka: " + marka + ", Garanti Süresi: " + garantiGunu + " gün";
    }
}