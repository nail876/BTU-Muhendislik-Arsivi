package com.bank.app.people; // Kisi sınıfının paketi

public abstract class Kisi {
    private String ad, soyad, email;
    private int telefonNumarasi;

    public Kisi(String ad, String soyad, String email, int tel) {
        this.ad = ad;
        this.soyad = soyad;
        this.email = email;
        this.telefonNumarasi = tel;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTelefonNumarasi() {
        return telefonNumarasi;
    }

    public void setTelefonNumarasi(int telefonNumarasi) {
        this.telefonNumarasi = telefonNumarasi;
    }

    @Override
    public String toString() {
        return "Ad: " + ad + " " + soyad + " | Email: " + email + " | Tel: " + telefonNumarasi;
    }
}