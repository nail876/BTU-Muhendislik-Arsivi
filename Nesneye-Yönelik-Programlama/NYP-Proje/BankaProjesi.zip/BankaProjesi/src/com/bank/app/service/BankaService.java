package com.bank.app.service;

import com.bank.app.accounts.BankaHesabi;
import com.bank.app.accounts.VadesizHesap;
import com.bank.app.accounts.YatirimHesabi;
import com.bank.app.cards.KrediKarti;
import com.bank.app.people.BankaPersoneli;
import com.bank.app.people.Musteri;

public class BankaService {

    // Müşteri oluşturma işlemini yapar.
    // Bu metot, yeni bir Musteri nesnesi yaratır ve uygulama akışına hazır hale getirir.
    public Musteri musteriOlustur(String ad, String soyad, String email, int telefon) {
        Musteri musteri = new Musteri(ad, soyad, email, telefon);
        System.out.println("Musteri olusturuldu: " + musteri);
        return musteri;
    }

    // Banka personeli oluşturma işlemi.
    // Personel, ileride müşteriye atanabilir ve müşteri listesini yönetebilir.
    public BankaPersoneli personelOlustur(String ad, String soyad, String email, int telefon) {
        BankaPersoneli personel = new BankaPersoneli(ad, soyad, email, telefon);
        System.out.println("Personel olusturuldu: " + personel);
        return personel;
    }

    // Müşteri adına hesap açma işlemini soyutlar.
    // Hesap türüne göre vadesiz veya yatırım hesabı oluşturur.
    public BankaHesabi hesapAc(Musteri musteri, String tip, double bakiye) {
        BankaHesabi hesap = musteri.hesapEkle(tip, bakiye);
        if (hesap != null) {
            System.out.println("Hesap acildi: " + hesap);
        }
        return hesap;
    }

    // Müşteriye kredi kartı tanımlar.
    // Kart limiti ve borcu müşteri objesine eklenir.
    public KrediKarti krediKartiTanimla(Musteri musteri, double limit, double borc) {
        KrediKarti kart = musteri.krediKartiEkle(limit, borc);
        System.out.println("Kredi karti tanimlandi: " + kart);
        return kart;
    }

    // Hesaplara para yatırma işlemi.
    // Yatırım hesabı için özel metot kullanılır, diğer hesaplarda doğrudan bakiye artırılır.
    public void paraYatir(BankaHesabi hesap, double miktar) {
        if (miktar <= 0) {
            System.out.println("Lutfen pozitif miktar giriniz.");
            return;
        }
        if (hesap instanceof YatirimHesabi) {
            ((YatirimHesabi) hesap).paraEkle(miktar);
        } else {
            hesap.setBakiye(hesap.getBakiye() + miktar);
            System.out.println(miktar + " TL hesaba yatirildi: " + hesap);
        }
    }

    // Vadesiz hesaptan başka bir hesaba para gönderme işlemi.
    // Gönderen hesaptan para düşülür, alıcı hesaba eklenir.
    public void hesaplarArasiTransfer(VadesizHesap gonderen, BankaHesabi alici, double miktar) {
        System.out.println("Transfer islemi: " + miktar + " TL");
        gonderen.paraTransferi(alici, miktar);
    }

    // Kredi kartı borcunu ödeme işlemi.
    // Kullanıcı vadesiz hesabından kart borcunu kapatmaya çalışır.
    public void krediKartiBorcOdeme(VadesizHesap hesap, KrediKarti kart, double miktar) {
        System.out.println("Kredi karti borcu odeme islemi: " + miktar + " TL");
        hesap.krediKartiBorcOdeme(kart, miktar);
    }

    // Müşteriye ait hesabı silme işlemini yönlendirir.
    public void hesapSil(Musteri musteri, BankaHesabi hesap) {
        musteri.hesapSil(hesap);
    }

    // Müşteriye ait kredi kartını silme işlemini yönlendirir.
    public void krediKartiSil(Musteri musteri, KrediKarti kart) {
        musteri.krediKartiSil(kart);
    }
}

