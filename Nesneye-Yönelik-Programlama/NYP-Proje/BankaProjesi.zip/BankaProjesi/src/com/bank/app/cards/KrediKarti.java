package com.bank.app.cards;

import java.util.Random;

public class KrediKarti {
    private String kartNo;
    private double limit;
    private double guncelBorc;

    public KrediKarti(double limit, double borc) {
        this.limit = limit;
        this.guncelBorc = borc;
        this.kartNo = "4444-" + (new Random().nextInt(9000) + 1000);
    }

    public String getKartNo() {
        return kartNo;
    }

    public double getLimit() {
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }

    public double getGuncelBorc() {
        return guncelBorc;
    }

    public void setGuncelBorc(double b) {
        this.guncelBorc = b;
    }

    @Override
    public String toString() {
        return "Kart: " + kartNo + " | Limit: " + limit + " TL | Borc: " + guncelBorc + " TL";
    }
}
